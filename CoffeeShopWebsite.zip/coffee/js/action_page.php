<?php
$username = "root";
$hostname = "localhost"; 
//connection to the database
$dbhandle = mysqli_connect($hostname, $username);
echo "Connected to MySQL<br>";
//select a database to work with
$selected = 
mysqli_select_db($dbhandle,"$demo");
//execute the SQL query and return records
$result = mysqli_query($dbhandle ,"SELECT email, password FROM 2");
while ($row = mysqli_fetch_array($result)) 
{
echo " Email:".$row{'email'}."password: ".$row{'password'}."<br>";
}