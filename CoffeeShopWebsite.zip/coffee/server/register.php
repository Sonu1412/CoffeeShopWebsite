<?php
require_once("config.php");

if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if($password == $confirm_password) {
        $query = mysqli_query($conn, "SELECT * FROM `users` WHERE `username`='$username' AND `password`='$password'");
        if(mysqli_num_rows($query) > 0) {
            header("Location: /coffee/home.html?msg=User exists already. Please Login !!");
        } else {
            $insert_query = mysqli_query($conn, "INSERT INTO `users`(`username`, `password`) VALUES ('$username','$password')");
            header("Location: /coffee/home.html?msg=Registration Successfull. Please Login Now !!");
        }
    } else {
        header("Location: /coffee/home.html?msg=Password and Confirm Password are not same.");
    }
    
}

?>