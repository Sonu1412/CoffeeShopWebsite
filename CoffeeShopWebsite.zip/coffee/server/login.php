<?php
require_once("config.php");

if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = mysqli_query($conn, "SELECT * FROM `users` WHERE `username`='$username' AND `password`='$password'");
    if(mysqli_num_rows($query) > 0) {
        echo "Login Successfull";
        header("Location: /coffee/index.html?msg=Login Successfull !!");
    } else {
        echo "Login Failed\n<p>If you don't have an account <a href='http://localhost/coffee/signup.html'><u>Register here</u></a></p>";
    }
}

?>