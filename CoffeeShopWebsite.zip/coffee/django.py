import django.urls
from mysqlx import View
from . import views
import render, HttpResponse
urlpatterns = [views('',View.show)]
